//  req/rep envelope request.
//  Note that the zhelpers.h file also provides s_sendmore

#include "zhelpers.h"
#include "yunpub.h"

#include <unistd.h>

static void *context = NULL;
static void *client = NULL;

int yunreq_start (int port)
{
    char connto[128];

    snprintf(connto, sizeof connto, "tcp://192.168.209.142:%d", port);
    if (!context && !client) {
        context = zmq_ctx_new ();
        client  = zmq_socket (context, ZMQ_REQ);
        zmq_connect (client, connto);
    }

    return 0;
}

int yunreq_stop (void)
{
    if (context && client) {
        zmq_close (client);
        zmq_ctx_destroy (context);
    }

    return 0;
}

int yunreq_send (char *topic, unsigned char *data, int datalen)
{
    char string[128];
    if (client) {
        s_sendmore (client, topic);
        s_sendbin (client, data, datalen);
        s_recvbin (client, string, sizeof string);
		printf("sssss %s\n", string);
    }
	return 0;
}
