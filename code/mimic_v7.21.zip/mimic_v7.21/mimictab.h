#ifndef __MIMICTAB_H_INCLUDED__
#define __MIMICTAB_H_INCLUDED__

#ifndef ETHER_ADDR_LEN
#define ETHER_ADDR_LEN 6
#endif

#define MIMIC_TAB_IDLE              0
#define MIMIC_TAB_INPORTSTATS       1
#define MIMIC_TAB_INSOFTVER         2
#define MIMIC_TAB_OUTACL            1001
#define MIMIC_TAB_OUTPORTIP         1002
#define MIMIC_TAB_OUTFIB            1003
#define MIMIC_TAB_OUTARP            1004
#define MIMIC_TAB_OUTFDB            1005
#define MIMIC_TAB_OUTPORTSTP        1006
#define MIMIC_TAB_OUTVLAN           1007
#define MIMIC_TAB_OUTSWITCHPORT     1008
#define MIMIC_TAB_OUTLAG            1009
#define MIMIC_TAB_OUTPORTCONF       1010
#define MIMIC_TAB_OUTMIRROR         1011
#define MIMIC_TAB_OUTHISTORY        1012
#define MIMIC_TAB_OUTSYNCCMD        1013

#define MIMIC_OPR_ADD               1
#define MIMIC_OPR_DEL               2
#define MIMIC_OPR_MOD               3

#define MIMIC_PORTNAME_LEN          64
#define MIMIC_IDLE_INTERVAL         1 // idle peer 1s.

/*
 * Client to request server periodically.
 * If server haven't control message, need reply idle as same.
 */
struct mimic_idle { 
    unsigned int type;
    char desc[32];
};

struct mimic_portStats {
    unsigned int type;
    unsigned int opr;
    unsigned int portNum;
    char portName[MIMIC_PORTNAME_LEN];
#define MIMIC_PORTSTATS_PHYSTATE_DOWN  0
#define MIMIC_PORTSTATS_PHYSTATE_UP    1
    unsigned int phyState;
    unsigned long long txCount;
    unsigned long long rxCount;
    unsigned long long crcErrCount; /* fcs error count */
    unsigned int speed; /* Mbps */
};

struct mimic_softVer {
    unsigned int type;
    char version[128];
};

struct mimic_acl {
    unsigned int type;
    unsigned int opr;
#define MIMIC_ACL_FLAGS_DSTIP      (1<<6)
#define MIMIC_ACL_FLAGS_SRCIP      (1<<7)
    unsigned int flags; // Indicat ipAddr whether valid.
#define MIMIC_ACL_DIR_INGRESS      1
#define MIMIC_ACL_DIR_EGRESS       2
    unsigned int dir;
    unsigned int portNum;
    unsigned char dstMac[ETHER_ADDR_LEN];
    unsigned char srcmac[ETHER_ADDR_LEN];
    unsigned int vlanId;
    unsigned int ethType;
    unsigned int dstIpAddr;
    unsigned int srcIpAddr;
    unsigned int dscp;
    unsigned int protocol;
    unsigned int dstPort;
    unsigned int srcPort;
#define MIMIC_ACL_ACTION_RDIRT     0
#define MIMIC_ACL_ACTION_DENY      1
#define MIMIC_ACL_ACTION_ACCEPT    2
    unsigned int action; /* drop or accept */
    unsigned int redirect; /* port number reirect to */
};

struct mimic_portIpAddr {
    unsigned int type;
    unsigned int opr;
    unsigned int portNum;
    char portName[MIMIC_PORTNAME_LEN];  
    unsigned int ipAddr;
    unsigned int netmask;
    unsigned int vlanId;
};

struct mimic_fib { //router information using to forwarding.
    unsigned int type;
    unsigned int opr;
    unsigned int network;
    unsigned int netmask;
    unsigned int nexthop;
    unsigned int outPort;
};

struct mimic_arp {
    unsigned int type;
    unsigned int opr;
    unsigned int ipAddr;
    unsigned char macAddr[ETHER_ADDR_LEN];
    unsigned char pad[2];
    unsigned int portNum;
    unsigned int vlanId;
};

struct mimic_fdb { //mac information using to forwarding ethernet frame.
    unsigned int type;
    unsigned int opr;
    unsigned char macAddr[ETHER_ADDR_LEN];
    unsigned char pad[2];
    unsigned int vlanId;
    unsigned int portNum;
#define MIMIC_FDB_ORIGNTYPE_DYNAMIC  1
#define MIMIC_FDB_ORIGNTYPE_STATIC   2
    unsigned int orignType;
};

struct mimic_portStp {
    unsigned int type;
    unsigned int opr;
    unsigned int vlanId;
    unsigned int portNum;
    /* RSTP (802.1W) is an evolution of the older STP (802.1D).
       discard (merged blocking, listening, disabled), forwarding, learning,  */
#define MIMIC_PORTSTP_STATEFLAG_BLOCKING     (1<<0)
#define MIMIC_PORTSTP_STATEFLAG_DISCARD      (1<<1)
#define MIMIC_PORTSTP_STATEFLAG_FORWARDING   (1<<2)
#define MIMIC_PORTSTP_STATEFLAG_LEARNING     (1<<3)
#define MIMIC_PORTSTP_STATEFLAG_LISTENING    (1<<4)
    unsigned int portFlags;
};

struct mimic_vlan {
    unsigned int type;
    unsigned int opr;
    unsigned int vlanId;
    unsigned int portNum;
    unsigned int tagged;
};

struct mimic_switchPort {
    unsigned int type;
    unsigned int opr;
#define MIMIC_SWITCHPORT_SWITCHTYPE_ACCESS  1   
#define MIMIC_SWITCHPORT_SWITCHTYPE_TRUNK   2
#define MIMIC_SWITCHPORT_SWITCHTYPE_HYBRID  3
    unsigned char switchType;
    unsigned int vlanId;
    unsigned int portNum;
};

struct mimic_lag {
    unsigned int type;
    unsigned int opr;
#define MIMIC_LAG_LAGMODE_STATIC    1
#define MIMIC_LAG_LAGMODE_LACP      2
    unsigned int lagMode; /* static or lacp */
    unsigned int lagId;
    char lagName[MIMIC_PORTNAME_LEN];
    unsigned int memPort;
};

struct mimic_portConf {
    unsigned int type;
    unsigned int opr;
    unsigned int portNum;
    unsigned int speed;
#define MIMIC_PORTCONF_ADMINSTATE_DOWN  0   
#define MIMIC_PORTCONF_ADMINSTATE_UP    1
    unsigned int adminState;
    unsigned int rateIn; /* Mbps */
    unsigned int rateOut; /* Mbps */
};

struct mimic_mirror {
    unsigned int type;
    unsigned int opr;
    unsigned int session;
    unsigned int srcPort;
    unsigned int vlanId;
    unsigned int dstPort;
#define MIMIC_MIRROR_MODE_RX    0
#define MIMIC_MIRROR_MODE_TX    1
#define MIMIC_MIRROR_MODE_BIDIR 2
    unsigned int mode;
};

struct mimic_history {
    unsigned int type;
    unsigned int opr;
    unsigned int length; /* if history size more than 256, this field need indicast real size */
    char history[256];
};

struct mimic_syncCmd {
    unsigned int type;
    unsigned int opr;
    unsigned int cmdLen;
    char cmd[256]; /* !mimicSync indicate the above commands is credit */
};

#endif /* __MIMICTAB_H_INCLUDED__ */
