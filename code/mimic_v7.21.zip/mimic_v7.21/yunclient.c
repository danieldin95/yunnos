//  raw tcp client.

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <arpa/inet.h>
#include <syslog.h>
#include <pthread.h>
#include <errno.h>

#include "network.h"
#include "yunclient.h"

int yunclientfd = -1;

#define YUNCLIENT_MESGCB_MAX 256

static mesgCb mesgCbs[YUNCLIENT_MESGCB_MAX] = {NULL};

void yunclient_init() {
    static int inited = 0;
    if (!inited) {
		memset(mesgCbs, 0, sizeof mesgCbs);
		inited = 0x01;
    }

	syslog(LOG_INFO, "%s: %d to %p\n", __FUNCTION__, 1, mesgCbs[1]);
	syslog(LOG_INFO, "%s: %d to %p\n", __FUNCTION__, 2, mesgCbs[2]);
	syslog(LOG_INFO, "%s: %d to %p\n", __FUNCTION__, 3, mesgCbs[3]);
	syslog(LOG_INFO, "%s: %d to %p\n", __FUNCTION__, 4, mesgCbs[4]);
	syslog(LOG_INFO, "%s: %d to %p\n", __FUNCTION__, 5, mesgCbs[5]);
}

int yunclient_start (char *addr, int port){
    struct sockaddr_in server_addr;

    yunclient_init();
    
    if (yunclientfd <= 0) {
        yunclientfd = socket(AF_INET, SOCK_STREAM, 0);
         
        bzero(&server_addr, sizeof(server_addr));
        server_addr.sin_family = AF_INET;
        server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
        server_addr.sin_port   = htons(port);
        inet_pton(AF_INET, addr, &server_addr.sin_addr);

        if(connect(yunclientfd, (struct sockaddr *)&server_addr, sizeof(struct sockaddr_in)) < 0){
            syslog(LOG_ERR, "connect server %s\n", strerror(errno));
			yunclientfd = -1;
            return -1;
        }

		syslog(LOG_ERR, "connect server on %d\n", yunclientfd);
    }

    return 0;
}

int yunclient_stop (void) {
    if (yunclientfd > 0) {
        close (yunclientfd);
    }

    return 0;
}

int 
yunclient_send (char *topic, unsigned char *data, int datalen) {
    int rlen  = 0;
    int tlen = 0;
	unsigned char buf[YUNBUF_LEN];
    unsigned char *p = NULL;

    assert(NULL != topic);
    assert(NULL != data);

    syslog(LOG_INFO, "%s: send topic %s data %d\n", __FUNCTION__, topic, datalen);

    if (yunclientfd > 0) {
		tlen = strlen(topic) + 1;
        rlen += sizeof(rlen) + tlen + datalen; 

		if (rlen > sizeof(buf)) {
			syslog(LOG_ERR, "%s: too big size: %d\n", __FUNCTION__, rlen);
			return -1;
		}

        p = buf;
		memcpy(p, &rlen, sizeof(rlen));
		p += sizeof(rlen);
		memcpy(p, topic, tlen);
		p += tlen;
		memcpy(p, data, datalen);
		p += datalen;

        if(writen(yunclientfd, buf, rlen) != rlen) {
            syslog(LOG_ERR, "%s: write data to %d len %s\n", __FUNCTION__, yunclientfd, strerror(errno));
            return -1;
        }

		syslog(LOG_INFO, "%s: send topic %s data %d ok\n", __FUNCTION__, topic, rlen);
    }
    return 0;
}

static int
yunclient_mesg_dis(unsigned char *data, int datalen) {
    unsigned char *datap = data;
    unsigned int   type  = 0;
    mesgCb         func  = NULL;

    assert(NULL != data);

    syslog(LOG_INFO, "%s: receive len: %d data: %s\n", __FUNCTION__, datalen, data);
    while(((datap-data) < datalen) && (*(datap) != 0)) datap++;

	datap++; //ignore '\x00'
	
    type = *(unsigned int *)datap;
    if (type >= YUNCLIENT_MESGCB_MAX) {
        syslog(LOG_ERR, "%s: too big type: %d\n", __FUNCTION__, type);
        return -1;
    }

    if ((func = mesgCbs[type]) == NULL) {
        syslog(LOG_ERR, "%s: not found handle for mesg type: %d\n", __FUNCTION__, type);
        return -1;
    }

    return func((void *)datap, datalen-(datap-data));
}

void 
yunclient_mesg_reg(unsigned int type, mesgCb func) {
    yunclient_init();

    if (type >= YUNCLIENT_MESGCB_MAX) {
        syslog(LOG_INFO, "%s: too big type: %d\n", __FUNCTION__, type);
        return;
    }

	syslog(LOG_INFO, "%s: register %d to %p\n", __FUNCTION__, type, func);

    mesgCbs[type] = func;
}

int
yunclient_loop(int sock) {
    int header = 0;
    int ret    = 0;
    unsigned char buf[YUNBUF_LEN];

    if (sock <= 0) {
        return -1;
    }

    ret = readn(sock, (void *)&header, sizeof(header));
    if (ret != sizeof header) {
        syslog(LOG_ERR, "too small size %d\n", sizeof(header));
        return -1;
    }

	header = header - sizeof(header);
    memset(buf, 0, sizeof(buf));
    
    if (header > sizeof(buf)) {
        syslog(LOG_ERR, "too long size %d\n", header);
        return -1;
    }

    ret = readn(sock, buf, header);
    if (ret != header) {
        return -1;
    }

    yunclient_mesg_dis(buf, header);

	return 0;
}


static void 
yunclient_loopforever(void *argv) {
    int ret = 0;
    if (yunclientfd <= 0) {
        return;
    }

    do {
        ret = yunclient_loop(yunclientfd);
    }while(ret >= 0);

    syslog(LOG_ERR, "exit\n");
}

int 
yunclient_run() {
    int ret = 0;
    static pthread_t id;

    if (yunclientfd <= 0) {
        return -1;
    }
    
    ret = pthread_create(&id, NULL, (void *)yunclient_loopforever, NULL);
    if(ret != 0) {
        syslog(LOG_ERR, "create pthread error!\n");
    }

    return ret;
}
