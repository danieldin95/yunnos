#include "yunreq.h"

int main()
{
	yunreq_start(YUNREQ_XSHELLPORT);
	yunreq_send("daniel", "hi", 3);
	yunreq_send("daniel", "??i", 4);
}
