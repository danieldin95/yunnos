#ifndef __YUNPUB_H_INCLUDED__
#define __YUNPUB_H_INCLUDED__

#include "mimictab.h"

#define YUNPUB_PORT 		         5563
#define YUNPUB_XNETSRVPORT           YUNPUB_PORT
#define YUNPUB_HALPORT               YUNPUB_PORT

#define YUNPUB_TITLE_VLAN  "vlanTab"
#define YUNPUB_TITLE_FDB   "fdbTab"
#define YUNPUB_TITLE_STP   "stpTab"
#define YUNPUB_TITLE_FIB   "fibTab"
#define YUNPUB_TITLE_ARP   "arpTab"
#define YUNPUB_TITLE_ACL   "aclTab"
#define YUNPUB_TITLE_LAG   "lagTab"
#define YUNPUB_TITLE_SWPORT   "switchPortTab"
#define YUNPUB_TITLE_PORTCFG  "portConfTab"
#define YUNPUB_TITLE_MIRROR   "mirrorTab"
#define YUNPUB_TITLE_PORTIP   "portIpTab"

int yunpub_start (int port);
int yunpub_stop (void);
int yunpub_send (char *topic, unsigned char *data, int datalen);

#endif /* __YUNPUB_H_INCLUDED__ */
