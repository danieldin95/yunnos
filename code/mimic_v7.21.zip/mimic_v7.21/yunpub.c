//  Pubsub envelope publisher
//  Note that the zhelpers.h file also provides s_sendmore

#include "zhelpers.h"
#include "yunpub.h"

#include <unistd.h>

#if 0

static void *context = NULL;
static void *publisher = NULL;

int yunpub_start (int port)
{
	char bindto[128];

	snprintf(bindto, sizeof bindto, "tcp://*:%d", port);
	if (!context && !publisher) {
    	context = zmq_ctx_new ();
		publisher = zmq_socket (context, ZMQ_PUB);
	    zmq_bind (publisher, bindto);
		//printf("start yunpub on %s\n", bindto);
	}

	return 0;
}

int yunpub_stop (void)
{
	if (context && publisher) {
    	zmq_close (publisher);
    	zmq_ctx_destroy (context);
	}

    return 0;
}

int yunpub_send (char *topic, unsigned char *data, int datalen)
{
	if (publisher) {
		s_sendmore (publisher, topic);
		s_sendbin (publisher, data, datalen);
	}
}
#endif
