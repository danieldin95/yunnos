#ifndef __YUNCLIENT_H_INCLUDED__
#define __YUNCLIENT_H_INCLUDED__

#include "mimictab.h"

#define YUNCLIENT_XSHELLPORT 		 5564

#define YUNCLIENT_TITLE_SYNCCMD      "syncCmdTab"
#define YUNCLIENT_TITLE_HISTORY      "historyTab"

#define YUNBUF_LEN                   1024

/******************************
 *       MESSAGE FORMAT
 * +-+-+-+-+-+-+-+-+-+-+-+-+-+
 * 0      7       15       32
 * +-+-+-+-+-+-+-+-+-+-+-+-+-+
 * |         Length          |
 * +-+-+-+-+-+-+-+-+-+-+-+-+-+
 * +         Topic           +
 * +-+-+-+-+-+-+-+-+-+-+-+-+-+
 * +         Payload         +
 * +-+-+-+-+-+-+-+-+-+-+-+-+-+
 *
 * Length: uint
 *  Total length of message
 * Topic: string
 *  The topic of message
 * Payload: struct or bytes
 *  The struct of mimic table
*******************************/

typedef int (*mesgCb)(void *data, int datalen);

extern int yunclientfd;

int yunclient_start (char *addr, int port);
int yunclient_stop (void);
int yunclient_send (char *topic, unsigned char *data, int datalen);
int yunclient_run();
void yunclient_mesg_reg(unsigned int type, mesgCb func);
int yunclient_loop(int sock);

#endif /* __YUNCLIENT_H_INCLUDED__ */
