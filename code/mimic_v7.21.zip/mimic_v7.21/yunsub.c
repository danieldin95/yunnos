//  Pubsub envelope subscriber
//  gcc -o yunsub yunsub.c -lzmq

#include "zhelpers.h"

int main (int argc, char *argv[])
{
    char *subTitle = "vlanTab";
	char *publisher="tcp://localhost:5563";
	unsigned char buf[256];
	unsigned int *data;
	int i = 0;

	if (argc < 3) {
      printf ("%s  PUBLISHER  TAB...\n", argv[0]);
	  return 0;
	}

	if (argc > 1) publisher = argv[1];

    void *context = zmq_ctx_new ();
    void *subscriber = zmq_socket (context, ZMQ_SUB);

    if (zmq_connect (subscriber, publisher) != 0) {
    	printf ("You need check publisher it's right.\n", publisher);
    }

	for (i = 2; i < argc; i++) {
	    subTitle = argv[i];
        zmq_setsockopt (subscriber, ZMQ_SUBSCRIBE, subTitle, 1);
		printf ("Subscribe %s\n", subTitle);
	}
	
    while (1) {
		memset(buf, 0, sizeof buf);
        char *address = s_recvstr (subscriber);
        char *contents = s_recvbin (subscriber, buf, sizeof buf);
	
		data = (unsigned int *)contents;
        printf ("[%s] 00-15 0x%08x %08x %08x %08x\n", address, data[0], data[1], data[2], data[3]);
		printf ("[%s] 16-32 0x%08x %08x %08x %08x\n", address, data[4], data[5], data[6], data[7]);
        if(!strcmp(address, "aclTab")){
            printf("[%s] 33-48 0x%08x %08x %08x %08x\n", address, data[8], data[9], data[10], data[11]);
            printf("[%s] 49-64 0x%08x %08x %08x %08x\n", address, data[12], data[13], data[14], data[15]);
        }
		printf ("\n");
        free (address);
    }
	
    //  We never get here, but clean up anyhow
    zmq_close (subscriber);
    zmq_ctx_destroy (context);
	
    return 0;
}
