#ifndef _MIMICAPI_H_
#define _MIMICAPI_H_

int if_indextono(int ifindex);
int if_aggnametomode(char *name);

#endif /*_MIMICAPI_H_*/
