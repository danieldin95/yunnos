#include <stdio.h>
#include <net/if.h>
#include <assert.h>
#include "mimictab.h"

int 
if_indextono(int ifindex) {
    int portno = -1;
    char ifname[MIMIC_PORTNAME_LEN];
	
	if (NULL == if_indextoname(ifindex, ifname)){
		return -1;
	}

    sscanf(ifname, "eth%d", &portno);

	return portno;
}

int 
if_aggnametomode(char *name) {
	assert(NULL != name);

	if (name[0] == 'p') return MIMIC_LAG_LAGMODE_STATIC;
	else if (name[0] == 's') return MIMIC_LAG_LAGMODE_LACP;

	return -1;
}
