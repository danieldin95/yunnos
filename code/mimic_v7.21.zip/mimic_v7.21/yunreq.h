#ifndef __YUNREQ_H_INCLUDED__
#define __YUNREQ_H_INCLUDED__

#include "mimictab.h"

#define YUNREQ_XSHELLPORT 		 5564

#define YUNREQ_TITLE_SYNCCMD   "syncCmdTab"
#define YUNREQ_TITLE_HISTORY   "historyTab"

int yunreq_start (int port);
int yunreq_stop (void);
int yunreq_send (char *topic, unsigned char *data, int datalen);

#endif /* __YUNREQ_H_INCLUDED__ */
